﻿namespace WindowsFormsApplication1
{
    partial class AnimeDatabaseWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AnimeDatabaseWindow));
            this.AddObtainedEpisodeButton = new System.Windows.Forms.Button();
            this.AddWatchedEpisodeButton = new System.Windows.Forms.Button();
            this.Add1toAll3Button = new System.Windows.Forms.Button();
            this.AddXtoAll3Button = new System.Windows.Forms.Button();
            this.ChangeKnownButton = new System.Windows.Forms.Button();
            this.ChangeObtainedButton = new System.Windows.Forms.Button();
            this.ChangeWatchedButton = new System.Windows.Forms.Button();
            this.temporaryItemReader = new System.Windows.Forms.Button();
            this.LoadDatabaseButton = new System.Windows.Forms.Button();
            this.SaveDatabaseButton = new System.Windows.Forms.Button();
            this.AddKnownEpisodeButton = new System.Windows.Forms.Button();
            this.databaseDisplay = new System.Windows.Forms.DataGridView();
            this.LockStatus = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.DeleteButton = new System.Windows.Forms.DataGridViewButtonColumn();
            this.EpisodesKnown = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EpisodesObtained = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EpisodesWatched = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DataType = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.CompletionStatus = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.UpToDateStatus = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.AnimeName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AnimeCountLabel = new System.Windows.Forms.Label();
            this.AnimeCountBox = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openDatabaseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveDatabaseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveAsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.versionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ChangeLockStatusButton = new System.Windows.Forms.Button();
            this.ChangeCompletionStatusButton = new System.Windows.Forms.Button();
            this.ChangeUpToDateStatusButton = new System.Windows.Forms.Button();
            this.toolTipsForButtons = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.databaseDisplay)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // AddObtainedEpisodeButton
            // 
            this.AddObtainedEpisodeButton.Location = new System.Drawing.Point(12, 107);
            this.AddObtainedEpisodeButton.Name = "AddObtainedEpisodeButton";
            this.AddObtainedEpisodeButton.Size = new System.Drawing.Size(142, 23);
            this.AddObtainedEpisodeButton.TabIndex = 2;
            this.AddObtainedEpisodeButton.Text = "Add an Obtained Episode";
            this.AddObtainedEpisodeButton.UseVisualStyleBackColor = true;
            this.AddObtainedEpisodeButton.Click += new System.EventHandler(this.AddObtainedEpisodeButton_Click);
            this.AddObtainedEpisodeButton.MouseHover += new System.EventHandler(this.AddObtainedEpisodeButton_MouseHover);
            // 
            // AddWatchedEpisodeButton
            // 
            this.AddWatchedEpisodeButton.Location = new System.Drawing.Point(12, 136);
            this.AddWatchedEpisodeButton.Name = "AddWatchedEpisodeButton";
            this.AddWatchedEpisodeButton.Size = new System.Drawing.Size(142, 23);
            this.AddWatchedEpisodeButton.TabIndex = 3;
            this.AddWatchedEpisodeButton.Text = "Add a Watched Episode";
            this.AddWatchedEpisodeButton.UseVisualStyleBackColor = true;
            this.AddWatchedEpisodeButton.Click += new System.EventHandler(this.AddWatchedEpisodeButton_Click);
            this.AddWatchedEpisodeButton.MouseHover += new System.EventHandler(this.AddWatchedEpisodeButton_MouseHover);
            // 
            // Add1toAll3Button
            // 
            this.Add1toAll3Button.Location = new System.Drawing.Point(12, 165);
            this.Add1toAll3Button.Name = "Add1toAll3Button";
            this.Add1toAll3Button.Size = new System.Drawing.Size(142, 23);
            this.Add1toAll3Button.TabIndex = 4;
            this.Add1toAll3Button.Text = "+1 to all 3";
            this.Add1toAll3Button.UseVisualStyleBackColor = true;
            this.Add1toAll3Button.Click += new System.EventHandler(this.Add1toAll3Button_Click);
            this.Add1toAll3Button.MouseHover += new System.EventHandler(this.Add1toAll3Button_MouseHover);
            // 
            // AddXtoAll3Button
            // 
            this.AddXtoAll3Button.Location = new System.Drawing.Point(12, 194);
            this.AddXtoAll3Button.Name = "AddXtoAll3Button";
            this.AddXtoAll3Button.Size = new System.Drawing.Size(142, 23);
            this.AddXtoAll3Button.TabIndex = 5;
            this.AddXtoAll3Button.Text = "+X to all 3";
            this.AddXtoAll3Button.UseVisualStyleBackColor = true;
            this.AddXtoAll3Button.Click += new System.EventHandler(this.AddXtoAll3Button_Click);
            this.AddXtoAll3Button.MouseHover += new System.EventHandler(this.AddXtoAll3Button_MouseHover);
            // 
            // ChangeKnownButton
            // 
            this.ChangeKnownButton.Location = new System.Drawing.Point(12, 223);
            this.ChangeKnownButton.Name = "ChangeKnownButton";
            this.ChangeKnownButton.Size = new System.Drawing.Size(142, 23);
            this.ChangeKnownButton.TabIndex = 6;
            this.ChangeKnownButton.Text = "Change Known";
            this.ChangeKnownButton.UseVisualStyleBackColor = true;
            this.ChangeKnownButton.Click += new System.EventHandler(this.ChangeKnownButton_Click);
            this.ChangeKnownButton.MouseHover += new System.EventHandler(this.ChangeKnownButton_MouseHover);
            // 
            // ChangeObtainedButton
            // 
            this.ChangeObtainedButton.Location = new System.Drawing.Point(12, 252);
            this.ChangeObtainedButton.Name = "ChangeObtainedButton";
            this.ChangeObtainedButton.Size = new System.Drawing.Size(142, 23);
            this.ChangeObtainedButton.TabIndex = 7;
            this.ChangeObtainedButton.Text = "Change Obtained";
            this.ChangeObtainedButton.UseVisualStyleBackColor = true;
            this.ChangeObtainedButton.Click += new System.EventHandler(this.ChangeObtainedButton_Click);
            this.ChangeObtainedButton.MouseHover += new System.EventHandler(this.ChangeObtainedButton_MouseHover);
            // 
            // ChangeWatchedButton
            // 
            this.ChangeWatchedButton.Location = new System.Drawing.Point(12, 281);
            this.ChangeWatchedButton.Name = "ChangeWatchedButton";
            this.ChangeWatchedButton.Size = new System.Drawing.Size(142, 23);
            this.ChangeWatchedButton.TabIndex = 8;
            this.ChangeWatchedButton.Text = "Change Watched";
            this.ChangeWatchedButton.UseVisualStyleBackColor = true;
            this.ChangeWatchedButton.Click += new System.EventHandler(this.ChangeWatchedButton_Click);
            this.ChangeWatchedButton.MouseHover += new System.EventHandler(this.ChangeWatchedButton_MouseHover);
            // 
            // temporaryItemReader
            // 
            this.temporaryItemReader.Enabled = false;
            this.temporaryItemReader.Location = new System.Drawing.Point(159, 24);
            this.temporaryItemReader.Name = "temporaryItemReader";
            this.temporaryItemReader.Size = new System.Drawing.Size(142, 23);
            this.temporaryItemReader.TabIndex = 10;
            this.temporaryItemReader.Text = "Show Elements";
            this.temporaryItemReader.UseVisualStyleBackColor = true;
            this.temporaryItemReader.Visible = false;
            // 
            // LoadDatabaseButton
            // 
            this.LoadDatabaseButton.Enabled = false;
            this.LoadDatabaseButton.Location = new System.Drawing.Point(307, 24);
            this.LoadDatabaseButton.Name = "LoadDatabaseButton";
            this.LoadDatabaseButton.Size = new System.Drawing.Size(142, 23);
            this.LoadDatabaseButton.TabIndex = 12;
            this.LoadDatabaseButton.Text = "Load Database";
            this.LoadDatabaseButton.UseVisualStyleBackColor = true;
            this.LoadDatabaseButton.Visible = false;
            // 
            // SaveDatabaseButton
            // 
            this.SaveDatabaseButton.Enabled = false;
            this.SaveDatabaseButton.Location = new System.Drawing.Point(455, 24);
            this.SaveDatabaseButton.Name = "SaveDatabaseButton";
            this.SaveDatabaseButton.Size = new System.Drawing.Size(142, 23);
            this.SaveDatabaseButton.TabIndex = 13;
            this.SaveDatabaseButton.Text = "Save Database";
            this.SaveDatabaseButton.UseVisualStyleBackColor = true;
            this.SaveDatabaseButton.Visible = false;
            // 
            // AddKnownEpisodeButton
            // 
            this.AddKnownEpisodeButton.Location = new System.Drawing.Point(12, 78);
            this.AddKnownEpisodeButton.Name = "AddKnownEpisodeButton";
            this.AddKnownEpisodeButton.Size = new System.Drawing.Size(142, 23);
            this.AddKnownEpisodeButton.TabIndex = 14;
            this.AddKnownEpisodeButton.Text = "Add a Known Episode";
            this.AddKnownEpisodeButton.UseVisualStyleBackColor = true;
            this.AddKnownEpisodeButton.Click += new System.EventHandler(this.AddKnownEpisodeButton_Click);
            this.AddKnownEpisodeButton.MouseHover += new System.EventHandler(this.AddKnownEpisodeButton_MouseHover);
            // 
            // databaseDisplay
            // 
            this.databaseDisplay.AllowUserToResizeColumns = false;
            this.databaseDisplay.AllowUserToResizeRows = false;
            this.databaseDisplay.BackgroundColor = System.Drawing.SystemColors.GrayText;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.databaseDisplay.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.databaseDisplay.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.databaseDisplay.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.LockStatus,
            this.DeleteButton,
            this.EpisodesKnown,
            this.EpisodesObtained,
            this.EpisodesWatched,
            this.DataType,
            this.CompletionStatus,
            this.UpToDateStatus,
            this.AnimeName});
            this.databaseDisplay.Location = new System.Drawing.Point(160, 49);
            this.databaseDisplay.MultiSelect = false;
            this.databaseDisplay.Name = "databaseDisplay";
            this.databaseDisplay.Size = new System.Drawing.Size(1019, 313);
            this.databaseDisplay.TabIndex = 16;
            this.databaseDisplay.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.databaseDisplay_CellClick);
            this.databaseDisplay.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.databaseDisplay_CellDoubleClick);
            this.databaseDisplay.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.databaseDisplay_RowsAdded);
            this.databaseDisplay.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.databaseDisplay_RowsRemoved);
            // 
            // LockStatus
            // 
            this.LockStatus.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle2.NullValue = false;
            this.LockStatus.DefaultCellStyle = dataGridViewCellStyle2;
            this.LockStatus.Frozen = true;
            this.LockStatus.HeaderText = "Lock";
            this.LockStatus.Name = "LockStatus";
            this.LockStatus.ReadOnly = true;
            this.LockStatus.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.LockStatus.ToolTipText = "This will prevent any checked rows from being edited or deleted.";
            this.LockStatus.Width = 37;
            // 
            // DeleteButton
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.NullValue = "Delete";
            this.DeleteButton.DefaultCellStyle = dataGridViewCellStyle3;
            this.DeleteButton.Frozen = true;
            this.DeleteButton.HeaderText = "Delete";
            this.DeleteButton.Name = "DeleteButton";
            this.DeleteButton.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.DeleteButton.Text = "";
            this.DeleteButton.ToolTipText = "Delete the anime in this row.";
            this.DeleteButton.Width = 50;
            // 
            // EpisodesKnown
            // 
            this.EpisodesKnown.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.EpisodesKnown.DefaultCellStyle = dataGridViewCellStyle4;
            this.EpisodesKnown.HeaderText = "Episodes Known";
            this.EpisodesKnown.MaxInputLength = 4;
            this.EpisodesKnown.Name = "EpisodesKnown";
            this.EpisodesKnown.ReadOnly = true;
            this.EpisodesKnown.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.EpisodesKnown.ToolTipText = "These are the episodes that are known to exist.";
            this.EpisodesKnown.Width = 83;
            // 
            // EpisodesObtained
            // 
            this.EpisodesObtained.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.EpisodesObtained.DefaultCellStyle = dataGridViewCellStyle5;
            this.EpisodesObtained.HeaderText = "Episodes Obtained";
            this.EpisodesObtained.Name = "EpisodesObtained";
            this.EpisodesObtained.ReadOnly = true;
            this.EpisodesObtained.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.EpisodesObtained.ToolTipText = "These are the episodes that you have in your possession.";
            this.EpisodesObtained.Width = 92;
            // 
            // EpisodesWatched
            // 
            this.EpisodesWatched.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.EpisodesWatched.DefaultCellStyle = dataGridViewCellStyle6;
            this.EpisodesWatched.HeaderText = "Episodes Watched";
            this.EpisodesWatched.Name = "EpisodesWatched";
            this.EpisodesWatched.ReadOnly = true;
            this.EpisodesWatched.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.EpisodesWatched.ToolTipText = "These are the episodes that you have watched.";
            this.EpisodesWatched.Width = 93;
            // 
            // DataType
            // 
            this.DataType.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.DataType.HeaderText = "Data Type";
            this.DataType.Items.AddRange(new object[] {
            "File",
            "Disc"});
            this.DataType.Name = "DataType";
            this.DataType.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.DataType.ToolTipText = "\"File\" means you have it on your computer, \"Disc\" means you have it on a dvd/blu-" +
    "ray/etc.";
            this.DataType.Width = 57;
            // 
            // CompletionStatus
            // 
            this.CompletionStatus.FalseValue = "";
            this.CompletionStatus.HeaderText = "Completion Status";
            this.CompletionStatus.Name = "CompletionStatus";
            this.CompletionStatus.ReadOnly = true;
            this.CompletionStatus.ToolTipText = "This denotes whether or not a series has aired all episodes.";
            // 
            // UpToDateStatus
            // 
            this.UpToDateStatus.HeaderText = "Up-to-Date Status";
            this.UpToDateStatus.Name = "UpToDateStatus";
            this.UpToDateStatus.ReadOnly = true;
            this.UpToDateStatus.ToolTipText = "This denotes whether or not you have watched all aired episodes.";
            // 
            // AnimeName
            // 
            this.AnimeName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.AnimeName.DefaultCellStyle = dataGridViewCellStyle7;
            this.AnimeName.HeaderText = "Anime Name";
            this.AnimeName.Name = "AnimeName";
            this.AnimeName.ReadOnly = true;
            this.AnimeName.Width = 85;
            // 
            // AnimeCountLabel
            // 
            this.AnimeCountLabel.AutoSize = true;
            this.AnimeCountLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AnimeCountLabel.Location = new System.Drawing.Point(12, 24);
            this.AnimeCountLabel.Name = "AnimeCountLabel";
            this.AnimeCountLabel.Size = new System.Drawing.Size(105, 20);
            this.AnimeCountLabel.TabIndex = 17;
            this.AnimeCountLabel.Text = "Anime Count:";
            // 
            // AnimeCountBox
            // 
            this.AnimeCountBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AnimeCountBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AnimeCountBox.Location = new System.Drawing.Point(119, 24);
            this.AnimeCountBox.Name = "AnimeCountBox";
            this.AnimeCountBox.ReadOnly = true;
            this.AnimeCountBox.Size = new System.Drawing.Size(29, 19);
            this.AnimeCountBox.TabIndex = 18;
            this.AnimeCountBox.Text = "0";
            this.AnimeCountBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.aboutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1191, 24);
            this.menuStrip1.TabIndex = 21;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openDatabaseToolStripMenuItem,
            this.saveDatabaseToolStripMenuItem,
            this.saveAsToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // openDatabaseToolStripMenuItem
            // 
            this.openDatabaseToolStripMenuItem.Name = "openDatabaseToolStripMenuItem";
            this.openDatabaseToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.openDatabaseToolStripMenuItem.Text = "Open";
            this.openDatabaseToolStripMenuItem.Click += new System.EventHandler(this.openDatabaseToolStripMenuItem_Click);
            // 
            // saveDatabaseToolStripMenuItem
            // 
            this.saveDatabaseToolStripMenuItem.Name = "saveDatabaseToolStripMenuItem";
            this.saveDatabaseToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.saveDatabaseToolStripMenuItem.Text = "Save";
            this.saveDatabaseToolStripMenuItem.Click += new System.EventHandler(this.saveDatabaseToolStripMenuItem_Click);
            // 
            // saveAsToolStripMenuItem
            // 
            this.saveAsToolStripMenuItem.Name = "saveAsToolStripMenuItem";
            this.saveAsToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.saveAsToolStripMenuItem.Text = "Save As...";
            this.saveAsToolStripMenuItem.Click += new System.EventHandler(this.saveAsToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(123, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.versionToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.aboutToolStripMenuItem.Text = "Help";
            // 
            // versionToolStripMenuItem
            // 
            this.versionToolStripMenuItem.Name = "versionToolStripMenuItem";
            this.versionToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.versionToolStripMenuItem.Text = "Version";
            this.versionToolStripMenuItem.Click += new System.EventHandler(this.versionToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.helpToolStripMenuItem.Text = "How to use...";
            this.helpToolStripMenuItem.Click += new System.EventHandler(this.helpToolStripMenuItem_Click);
            // 
            // ChangeLockStatusButton
            // 
            this.ChangeLockStatusButton.Location = new System.Drawing.Point(12, 49);
            this.ChangeLockStatusButton.Name = "ChangeLockStatusButton";
            this.ChangeLockStatusButton.Size = new System.Drawing.Size(142, 23);
            this.ChangeLockStatusButton.TabIndex = 22;
            this.ChangeLockStatusButton.Text = "Change Lock Status";
            this.ChangeLockStatusButton.UseVisualStyleBackColor = true;
            this.ChangeLockStatusButton.Click += new System.EventHandler(this.ChangeLockStatusButton_Click);
            this.ChangeLockStatusButton.MouseHover += new System.EventHandler(this.ChangeLockStatusButton_MouseHover);
            // 
            // ChangeCompletionStatusButton
            // 
            this.ChangeCompletionStatusButton.Location = new System.Drawing.Point(12, 310);
            this.ChangeCompletionStatusButton.Name = "ChangeCompletionStatusButton";
            this.ChangeCompletionStatusButton.Size = new System.Drawing.Size(142, 23);
            this.ChangeCompletionStatusButton.TabIndex = 23;
            this.ChangeCompletionStatusButton.Text = "Change Completion Status";
            this.ChangeCompletionStatusButton.UseVisualStyleBackColor = true;
            this.ChangeCompletionStatusButton.Click += new System.EventHandler(this.ChangeCompletionButton_Click);
            this.ChangeCompletionStatusButton.MouseHover += new System.EventHandler(this.ChangeCompletionStatusButton_MouseHover);
            // 
            // ChangeUpToDateStatusButton
            // 
            this.ChangeUpToDateStatusButton.Location = new System.Drawing.Point(12, 339);
            this.ChangeUpToDateStatusButton.Name = "ChangeUpToDateStatusButton";
            this.ChangeUpToDateStatusButton.Size = new System.Drawing.Size(142, 23);
            this.ChangeUpToDateStatusButton.TabIndex = 24;
            this.ChangeUpToDateStatusButton.Text = "Change Up-to-Date Status";
            this.ChangeUpToDateStatusButton.UseVisualStyleBackColor = true;
            this.ChangeUpToDateStatusButton.Click += new System.EventHandler(this.ChangeUpToDateButton_Click);
            this.ChangeUpToDateStatusButton.MouseHover += new System.EventHandler(this.ChangeUpToDateStatusButton_MouseHover);
            // 
            // AnimeDatabaseWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1191, 366);
            this.Controls.Add(this.ChangeUpToDateStatusButton);
            this.Controls.Add(this.ChangeCompletionStatusButton);
            this.Controls.Add(this.ChangeLockStatusButton);
            this.Controls.Add(this.AnimeCountBox);
            this.Controls.Add(this.AnimeCountLabel);
            this.Controls.Add(this.databaseDisplay);
            this.Controls.Add(this.AddKnownEpisodeButton);
            this.Controls.Add(this.SaveDatabaseButton);
            this.Controls.Add(this.LoadDatabaseButton);
            this.Controls.Add(this.temporaryItemReader);
            this.Controls.Add(this.ChangeWatchedButton);
            this.Controls.Add(this.ChangeObtainedButton);
            this.Controls.Add(this.ChangeKnownButton);
            this.Controls.Add(this.AddXtoAll3Button);
            this.Controls.Add(this.Add1toAll3Button);
            this.Controls.Add(this.AddWatchedEpisodeButton);
            this.Controls.Add(this.AddObtainedEpisodeButton);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "AnimeDatabaseWindow";
            this.Text = "Anime Database";
            ((System.ComponentModel.ISupportInitialize)(this.databaseDisplay)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button AddObtainedEpisodeButton;
        private System.Windows.Forms.Button AddWatchedEpisodeButton;
        private System.Windows.Forms.Button Add1toAll3Button;
        private System.Windows.Forms.Button AddXtoAll3Button;
        private System.Windows.Forms.Button ChangeKnownButton;
        private System.Windows.Forms.Button ChangeObtainedButton;
        private System.Windows.Forms.Button ChangeWatchedButton;
        private System.Windows.Forms.Button temporaryItemReader;
        private System.Windows.Forms.Button LoadDatabaseButton;
        private System.Windows.Forms.Button SaveDatabaseButton;
        private System.Windows.Forms.Button AddKnownEpisodeButton;
        private System.Windows.Forms.DataGridView databaseDisplay;
        private System.Windows.Forms.Label AnimeCountLabel;
        private System.Windows.Forms.TextBox AnimeCountBox;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openDatabaseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveDatabaseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Button ChangeLockStatusButton;
        private System.Windows.Forms.Button ChangeCompletionStatusButton;
        private System.Windows.Forms.Button ChangeUpToDateStatusButton;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem versionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolTip toolTipsForButtons;
        private System.Windows.Forms.ToolStripMenuItem saveAsToolStripMenuItem;
        private System.Windows.Forms.DataGridViewCheckBoxColumn LockStatus;
        private System.Windows.Forms.DataGridViewButtonColumn DeleteButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn EpisodesKnown;
        private System.Windows.Forms.DataGridViewTextBoxColumn EpisodesObtained;
        private System.Windows.Forms.DataGridViewTextBoxColumn EpisodesWatched;
        private System.Windows.Forms.DataGridViewComboBoxColumn DataType;
        private System.Windows.Forms.DataGridViewCheckBoxColumn CompletionStatus;
        private System.Windows.Forms.DataGridViewCheckBoxColumn UpToDateStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn AnimeName;
    }
}

