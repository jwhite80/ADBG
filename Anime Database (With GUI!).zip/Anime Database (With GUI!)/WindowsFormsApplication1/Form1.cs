﻿/*
Version 1.01
 * 
 * Fixed a bug where the lock status for
 * an anime wouldn't completely disable
 * its corresponding row.
 * 
Version 1.02
 * 
 * Fixed a bug hat prevented the user from
 * editing the name of an existing anime.
 * 
 * Disabled the window being resizable.
 * 
*/
using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class AnimeDatabaseWindow : Form
    {
        string [] animeNames = new string [1];
        string openedFileName = "temp.txt";
        //DataGridViewCell currentCell = null, previousCell = null;

        public AnimeDatabaseWindow()
        {
            InitializeComponent();
            
            

        }
        /*
        private void button1_Click(object sender, EventArgs e)
        {
            checkBox1.Checked = !checkBox1.Checked;
        }*/

        private void ChangeLockStatusButton_Click(object sender, EventArgs e)
        {
            try
            {
                ChangeCheckValue(0, sender, e);
                //turnButtonsOnOrOff((bool)databaseDisplay[0, databaseDisplay.CurrentCell.RowIndex].Value);
                turnRowOnOrOff(databaseDisplay.CurrentCell.RowIndex);
            }
            catch
            {
                //do nothing
            }
        }

        private void AddKnownEpisodeButton_Click(object sender, EventArgs e)
        {
            if (!checkLockStatus() != false)
            {
                if (databaseDisplay[2, databaseDisplay.CurrentCell.RowIndex].Value == null)
                {
                    databaseDisplay[2, databaseDisplay.CurrentCell.RowIndex].Value = 0;
                }
                else
                {
                    databaseDisplay[2, databaseDisplay.CurrentCell.RowIndex].Value = Convert.ToInt32(databaseDisplay[2, databaseDisplay.CurrentCell.RowIndex].Value) + 1;
                }
            }
        }

        private void AddObtainedEpisodeButton_Click(object sender, EventArgs e)
        {
            if (!checkLockStatus() != false)
            {
                if (databaseDisplay[3, databaseDisplay.CurrentCell.RowIndex].Value == null)
                {
                    databaseDisplay[3, databaseDisplay.CurrentCell.RowIndex].Value = 0;
                }
                else
                {
                    databaseDisplay[3, databaseDisplay.CurrentCell.RowIndex].Value = Convert.ToInt32(databaseDisplay[3, databaseDisplay.CurrentCell.RowIndex].Value) + 1;
                }
            }
        }

        private void AddWatchedEpisodeButton_Click(object sender, EventArgs e)
        {
            if (!checkLockStatus() != false)
            {
                if (databaseDisplay[4, databaseDisplay.CurrentCell.RowIndex].Value == null)
                {
                    databaseDisplay[4, databaseDisplay.CurrentCell.RowIndex].Value = 0;
                }
                else
                {
                    databaseDisplay[4, databaseDisplay.CurrentCell.RowIndex].Value = Convert.ToInt32(databaseDisplay[4, databaseDisplay.CurrentCell.RowIndex].Value) + 1;
                }
            }
        }

        private void Add1toAll3Button_Click(object sender, EventArgs e)
        {
            AddKnownEpisodeButton_Click(sender, e);
            AddObtainedEpisodeButton_Click(sender, e);
            AddWatchedEpisodeButton_Click(sender, e);
        }

        private void AddXtoAll3Button_Click(object sender, EventArgs e)
        {
            databaseDisplay.CurrentCell = databaseDisplay[2, databaseDisplay.CurrentCell.RowIndex];

            if (!checkLockStatus())
            {
                string input = Microsoft.VisualBasic.Interaction.InputBox("Enter the number of episodes to add for all three in the text box below.", "Add Episodes", "", SystemInformation.VirtualScreen.Width / 3, SystemInformation.VirtualScreen.Height / 3);

                try
                {
                    databaseDisplay[2, databaseDisplay.CurrentCell.RowIndex].Value = Convert.ToInt32(databaseDisplay[2, databaseDisplay.CurrentCell.RowIndex].Value) + Convert.ToInt32(input);
                    databaseDisplay[3, databaseDisplay.CurrentCell.RowIndex].Value = Convert.ToInt32(databaseDisplay[3, databaseDisplay.CurrentCell.RowIndex].Value) + Convert.ToInt32(input);
                    databaseDisplay[4, databaseDisplay.CurrentCell.RowIndex].Value = Convert.ToInt32(databaseDisplay[4, databaseDisplay.CurrentCell.RowIndex].Value) + Convert.ToInt32(input);
                }
                catch
                {
                    showErrorWindow("There can only be an integer in each of these three cells.");
                }
            }
        }

        private void ChangeKnownButton_Click(object sender, EventArgs e)
        {
            if (!checkLockStatus())
            {
                validateUserInput(2, "episodes known");
            }
        }

        private void ChangeObtainedButton_Click(object sender, EventArgs e)
        {
            if (!checkLockStatus())
            {
                validateUserInput(3, "episodes obtained");
            }
        }

        private void ChangeWatchedButton_Click(object sender, EventArgs e)
        {
            if (!checkLockStatus())
            {
                validateUserInput(4, "episodes watched");
            }
        }

        private void validateUserInput(int x, string episodeType)
        {
            //int temp = (int)databaseDisplay[x, databaseDisplay.CurrentCell.RowIndex].Value;

            //databaseDisplay[x, databaseDisplay.CurrentCell.RowIndex].ReadOnly = false;
            databaseDisplay.CurrentCell = databaseDisplay[x, databaseDisplay.CurrentCell.RowIndex];
            //databaseDisplay.BeginEdit(true);
            /*
            do
            {
                //Wait for the user to change the value.
            } while (temp == (int)databaseDisplay[x, databaseDisplay.CurrentCell.RowIndex].Value);*/

            //tempForm inputForm = new tempForm();

            string input = Microsoft.VisualBasic.Interaction.InputBox("Enter the new value for " + episodeType + " in the text box below.", "New Value", "", SystemInformation.VirtualScreen.Width/2, SystemInformation.VirtualScreen.Height/2);

            try
            {
                databaseDisplay[x, databaseDisplay.CurrentCell.RowIndex].Value = Convert.ToInt32(input);
            }
            catch
            {
                showErrorWindow("There can only be an integer in this cell.");
            }

            //showErrorWindow("There can only be an integer in this cell.");
        }

        private void showErrorWindow(string x)
        {
            MessageBox.Show(x, "Error", MessageBoxButtons.OK);
        }

        private void databaseDisplay_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            //string s = databaseDisplay[0, 0].Value.ToString();
            AnimeCountBox.Text = "" + (databaseDisplay.RowCount - 1);
            //databaseDisplay[0, databaseDisplay.CurrentCell.RowIndex].Value = false;
            //turnButtonsOnOrOff((bool)databaseDisplay[0, databaseDisplay.CurrentCell.RowIndex].Value);
        }

        private void databaseDisplay_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            AnimeCountBox.Text = "" + (databaseDisplay.RowCount - 1);
        }

        /*
        private void databaseDisplay_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if ((bool)databaseDisplay[0, databaseDisplay.CurrentCell.RowIndex].Value != true)// created column index (delete button)
            {
                //databaseDisplay.Rows.Remove(databaseDisplay.Rows[e.RowIndex]);

                //MessageBox.Show("" + databaseDisplay[0, databaseDisplay.CurrentCell.RowIndex].Value, "temp", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //commit the changes!
            }
        }*/

        private void databaseDisplay_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            bool temp = Convert.ToBoolean(databaseDisplay[0, databaseDisplay.CurrentCell.RowIndex].Value);

            if (e.ColumnIndex == 1 && databaseDisplay.RowCount > 1)// created column index (delete button)
            {
                if (e.RowIndex == databaseDisplay.RowCount - 1)
                {
                    MessageBox.Show("The last row, which contains no data, cannot be deleted.\n\n"
                    + "NOTE:  This row does not count towards the total number of anime series contained in the database",
                        "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (temp == false)
                {
                    databaseDisplay.Rows.Remove(databaseDisplay.Rows[e.RowIndex]);
                }
                //commit the changes!
            }
            else if (e.ColumnIndex == 1 && databaseDisplay.RowCount == 1)
            {
                MessageBox.Show("The minimum number of rows that can be in the table is 1.",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        /*
        //access anime names
        private void temporaryItemReader_Click(object sender, EventArgs e)
        {
            string s = "";
            //DataGridView dgv = (DataGridView)sender;
            //MessageBox.Show(dgv.SelectedRows[0].Cells[0].Value.ToString());

            
            
            for (int i = 0; i < databaseDisplay.ColumnCount; i++)
            {
                try
                {
                    s += databaseDisplay[i, databaseDisplay.CurrentCell.RowIndex].Value.ToString();
                    MessageBox.Show(s, "Contents", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    s = "";
                }
                catch (NullReferenceException u)
                {
                    MessageBox.Show("The cell at location [" + i + ", " + databaseDisplay.CurrentCell.RowIndex + "] contains no data to display.", "Notice", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }

            
        }*/

        private void ChangeCheckValue(int x, object sender, EventArgs e)
        {
            bool temp = Convert.ToBoolean(databaseDisplay[x, databaseDisplay.CurrentCell.RowIndex].Value);

            if (databaseDisplay[x, databaseDisplay.CurrentCell.RowIndex].Value == null)
            {
                databaseDisplay[x, databaseDisplay.CurrentCell.RowIndex].Value = true;
            }
            else
            {
                databaseDisplay[x, databaseDisplay.CurrentCell.RowIndex].Value = !Convert.ToBoolean(databaseDisplay[x, databaseDisplay.CurrentCell.RowIndex].Value);
            }
        }

        private void ChangeCompletionButton_Click(object sender, EventArgs e)
        {
            if (!checkLockStatus())
            {
                try
                {
                    ChangeCheckValue(6, sender, e);
                }
                catch
                {
                    //do nothing
                }
            }
        }

        private void ChangeUpToDateButton_Click(object sender, EventArgs e)
        {
            if (!checkLockStatus())
            {
                try
                {
                    ChangeCheckValue(7, sender, e);
                }
                catch
                {
                    //do nothing
                }
            }
        }

        private bool checkLockStatus()
        {
            try
            {
                return Convert.ToBoolean(databaseDisplay[0, databaseDisplay.CurrentCell.RowIndex].Value);
            }
            catch
            {
                return true;
            }
        }

        /*
        private void turnButtonsOnOrOff(bool x)
        {
            try
            {
                if (x == false)
                {
                    ChangeLockStatusButton.Enabled = true;
                    AddKnownEpisodeButton.Enabled = true;
                    AddObtainedEpisodeButton.Enabled = true;
                    AddWatchedEpisodeButton.Enabled = true;
                    Add1toAll3Button.Enabled = true;
                    AddXtoAll3Button.Enabled = true;
                    ChangeKnownButton.Enabled = true;
                    ChangeObtainedButton.Enabled = true;
                    ChangeWatchedButton.Enabled = true;
                    ChangeCompletionStatusButton.Enabled = true;
                    ChangeUpToDateStatusButton.Enabled = true;
                }
                else if (x == true)
                {
                    AddKnownEpisodeButton.Enabled = false;
                    AddObtainedEpisodeButton.Enabled = false;
                    AddWatchedEpisodeButton.Enabled = false;
                    Add1toAll3Button.Enabled = false;
                    AddXtoAll3Button.Enabled = false;
                    ChangeKnownButton.Enabled = false;
                    ChangeObtainedButton.Enabled = false;
                    ChangeWatchedButton.Enabled = false;
                    ChangeCompletionStatusButton.Enabled = false;
                    ChangeUpToDateStatusButton.Enabled = false;
                }
                else
                {
                    databaseDisplay[0, databaseDisplay.CurrentCell.RowIndex].Value = false;
                    turnButtonsOnOrOff((bool)databaseDisplay[0, databaseDisplay.CurrentCell.RowIndex].Value);
                }
            }

            catch (NullReferenceException u)
            {
                ChangeLockStatusButton.Enabled = true;
                AddKnownEpisodeButton.Enabled = true;
                AddObtainedEpisodeButton.Enabled = true;
                AddWatchedEpisodeButton.Enabled = true;
                Add1toAll3Button.Enabled = true;
                AddXtoAll3Button.Enabled = true;
                ChangeKnownButton.Enabled = true;
                ChangeObtainedButton.Enabled = true;
                ChangeWatchedButton.Enabled = true;
                ChangeCompletionStatusButton.Enabled = true;
                ChangeUpToDateStatusButton.Enabled = true;
            }
        }*/

        private void turnRowOnOrOff(int x)
        {

            databaseDisplay[1, x].ReadOnly = !databaseDisplay[1, x].ReadOnly;
            databaseDisplay[5, x].ReadOnly = !databaseDisplay[5, x].ReadOnly;
            
        }

        /*
        private void databaseDisplay_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                turnButtonsOnOrOff((bool)databaseDisplay[0, databaseDisplay.CurrentCell.RowIndex].Value);
            }
            catch (NullReferenceException u)
            {
                //do nothing
            }
        }

        /*
        private void databaseDisplay_RowLeave(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                turnButtonsOnOrOff((bool)databaseDisplay[0, databaseDisplay.CurrentCell.RowIndex].Value);
            }
            catch (NullReferenceException u)
            {
                //do nothing
            }
        }*/

        /*
        private void LoadDatabaseButton_Click(object sender, EventArgs e)
        {
            /*StreamWriter temp = File.CreateText("fileIOTest.txt");

            for(int i = 0; i < 9; i++)
            {
                if(i == 1)
                {
                    i++;
                }
                temp.WriteLine(databaseDisplay[i, 0].Value);
            }

            temp.Close();
            
            string fileName = Microsoft.VisualBasic.Interaction.InputBox("Enter the name of the file you wish to open (without the extension).", "Open", "", SystemInformation.VirtualScreen.Width / 3, SystemInformation.VirtualScreen.Height / 3) + ".txt";

            databaseDisplay.Rows.Add();

            int rows = 0, columns = 0;
            //string line = "";

            try
            {
                StreamReader primeRead = new StreamReader(fileName);
                StreamReader dataReader = new StreamReader(fileName);

                while (primeRead.ReadLine() != null)
                {
                    if (columns == 1)
                    {
                        columns++;
                    }

                    if (columns % 8 == 0 && columns > 0)
                    {
                        databaseDisplay[columns, rows].Value = dataReader.ReadLine();
                        columns = 0;
                        databaseDisplay.Rows.Add();
                        rows++;
                    }
                    else
                    {
                        databaseDisplay[columns, rows].Value = dataReader.ReadLine();

                        columns++;
                    }
                }

                /*
                while (columns != 8)
                {
                    //

               
                }

                databaseDisplay.Rows.RemoveAt(databaseDisplay.RowCount - 2);

                primeRead.Close();
                dataReader.Close();

                for (int i = 0; i < Convert.ToInt32(AnimeCountBox.Text) + 1; i++)
                {
                    try
                    {
                        if (Convert.ToBoolean(databaseDisplay[0, i].Value) == true)
                        {
                            turnRowOnOrOff(i);
                        }
                        else
                        {
                            databaseDisplay[8, i].ReadOnly = true;
                        }
                    }
                    catch
                    {
                        databaseDisplay[0, i].Value = false;
                        databaseDisplay[6, i].Value = false;
                        databaseDisplay[7, i].Value = false;
                    }
                }

                sortUnderlyingDataStructure();

                LoadDatabaseButton.Enabled = false;
                SaveDatabaseButton.Enabled = true;
            }
            catch
            {
                MessageBox.Show("That file does not exist.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                databaseDisplay.Rows.Remove(databaseDisplay.Rows[0]);
            }
        }*/

        /*
        private void SaveDatabaseButton_Click(object sender, EventArgs e)
        {
            string fileName = Microsoft.VisualBasic.Interaction.InputBox("Enter a name for this file.\n\nIf the file already exists it will be overwritten.", "Save", "", SystemInformation.VirtualScreen.Width / 3, SystemInformation.VirtualScreen.Height / 3) + ".txt";

            StreamWriter dataWriter = new StreamWriter(fileName);

            for (int i = 0; i < databaseDisplay.RowCount - 1; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    if (j != 1)
                    {
                        dataWriter.WriteLine(databaseDisplay[j, i].Value);
                    }
                }
            }

            dataWriter.Close();

            //databaseDisplay.Rows.Clear();

            //LoadDatabaseButton_Click(sender, e);
            
        }*/

        /*
        private void databaseDisplay_RowLeave(object sender, DataGridViewCellEventArgs e)
        {
            //MessageBox.Show("A row has lost focus.", "testing", MessageBoxButtons.OK, MessageBoxIcon.Information);
            try
            {
                if ((bool)databaseDisplay[0, databaseDisplay.CurrentCell.RowIndex].Value == true)
                {
                    //ChangeLockStatus.Enabled = false;
                    AddKnownEpisodeButton.Enabled = false;
                    AddObtainedEpisodeButton.Enabled = false;
                    AddWatchedEpisodeButton.Enabled = false;
                    Add1toAll3Button.Enabled = false;
                    AddXtoAll3Button.Enabled = false;
                    ChangeKnownButton.Enabled = false;
                    ChangeObtainedButton.Enabled = false;
                    ChangeWatchedButton.Enabled = false;
                    ChangeCompletionButton.Enabled = false;
                    ChangeUpToDateButton.Enabled = false;
                }
            }

            catch (NullReferenceException u)
            {
                ChangeLockStatus.Enabled = false;
                AddKnownEpisodeButton.Enabled = false;
                AddObtainedEpisodeButton.Enabled = false;
                AddWatchedEpisodeButton.Enabled = false;
                Add1toAll3Button.Enabled = false;
                AddXtoAll3Button.Enabled = false;
                ChangeKnownButton.Enabled = false;
                ChangeObtainedButton.Enabled = false;
                ChangeWatchedButton.Enabled = false;
                ChangeCompletionButton.Enabled = false;
                ChangeUpToDateButton.Enabled = false;
            }
        }*/
        
        
        /*
        private void databaseDisplay_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            MessageBox.Show("is this thing on?", "testing", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }*/
        
        
        
        
        /*
        private void databaseDisplay_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            MessageBox.Show("A cell value was changed", "Attention", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        */
        /*
        private void databaseDisplay_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            //MessageBox.Show("A cell value was changed", "Attention", MessageBoxButtons.OK, MessageBoxIcon.Information);

            if (databaseDisplay.CurrentCell == databaseDisplay[8, databaseDisplay.CurrentCell.RowIndex])
            {
                Array.Sort(animeNames);

                int index = Array.BinarySearch(animeNames, (databaseDisplay.CurrentCell.Value + "").ToLower());

                if (index < 0)
                {
                    //Anime name not found, do nothing.
                }
                else
                {
                    MessageBox.Show("That anime already exists in the database.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    //databaseDisplay[8, databaseDisplay.CurrentCell.RowIndex].Value = "";

                    //removeBadRow();

                    //databaseDisplay.CurrentCell = databaseDisplay[8, databaseDisplay.CurrentCell.RowIndex];

                    //databaseDisplay.BeginEdit(true);
                }
            }
        }

        /*
        private void databaseDisplay_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            int index = Array.BinarySearch(animeNames, databaseDisplay.CurrentCell.Value + "");

            if (index < 0)
            {
                //Anime name not found, do nothing.
            }
            else
            {
                databaseDisplay.CurrentCell = previousCell;

                //e.Cancel = true;
            }
        }*/

        private void databaseDisplay_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (databaseDisplay.CurrentCell == databaseDisplay[8, databaseDisplay.CurrentCell.RowIndex] && Convert.ToBoolean(databaseDisplay[0, databaseDisplay.CurrentCell.RowIndex].Value) == false)
            {
                string input = Microsoft.VisualBasic.Interaction.InputBox("Enter the new name for this anime (" + databaseDisplay[8, databaseDisplay.CurrentCell.RowIndex].Value +").", "Change Anime Name", "", SystemInformation.VirtualScreen.Width / 3, SystemInformation.VirtualScreen.Height / 3);
                int index = Array.BinarySearch(animeNames, input.ToLower());

                if (input != "" && index < 0)
                {
                    if (databaseDisplay.CurrentCell.RowIndex == Convert.ToInt32(AnimeCountBox.Text))
                    {
                        databaseDisplay.Rows.Add();
                        databaseDisplay.CurrentCell = databaseDisplay[8, Convert.ToInt32(AnimeCountBox.Text) - 1];
                        databaseDisplay[8, databaseDisplay.CurrentCell.RowIndex].Value = input;

                        sortUnderlyingDataStructure();
                    }
                    else
                    {
                        databaseDisplay[8, databaseDisplay.CurrentCell.RowIndex].Value = input;

                        sortUnderlyingDataStructure();
                    }
                }
                else if (input == "" && index < 0)
                {
                    //The user hit the Cancel button, do nothing.
                }
                else
                {
                    MessageBox.Show("That anime already exists in the database.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        /*
        private void removeBadRow()
        {
            databaseDisplay.CancelEdit();

            databaseDisplay.Invalidate();

            
            //databaseDisplay.CurrentCell = databaseDisplay[8, databaseDisplay.CurrentCell.RowIndex - 2];

            databaseDisplay.Rows.Remove(databaseDisplay.Rows[Convert.ToInt32(AnimeCountBox.Text)]);
        }*/

        private void sortUnderlyingDataStructure()
        {
            animeNames = new string[databaseDisplay.RowCount - 1];

            for (int i = 0; i < databaseDisplay.RowCount - 1; i++)
            {
                animeNames[i] = (databaseDisplay[8, i].Value + "").ToLower();
            }

            Array.Sort(animeNames);
        }

        private void openDatabaseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string fileName = Microsoft.VisualBasic.Interaction.InputBox("Enter the name of the file you wish to open (without the extension).", "Open", "", SystemInformation.VirtualScreen.Width / 3, SystemInformation.VirtualScreen.Height / 3) + ".txt";
            openedFileName = fileName;

            databaseDisplay.Rows.Clear();

            databaseDisplay.Rows.Add();

            int rows = 0, columns = 0;

            try
            {
                StreamReader primeRead = new StreamReader(fileName);
                StreamReader dataReader = new StreamReader(fileName);

                while (primeRead.ReadLine() != null)
                {
                    if (columns == 1)
                    {
                        columns++;
                    }

                    if (columns % 8 == 0 && columns > 0)
                    {
                        databaseDisplay[columns, rows].Value = dataReader.ReadLine();
                        columns = 0;
                        databaseDisplay.Rows.Add();
                        rows++;
                    }
                    else
                    {
                        databaseDisplay[columns, rows].Value = dataReader.ReadLine();

                        columns++;
                    }
                }

                databaseDisplay.Rows.RemoveAt(databaseDisplay.RowCount - 2);

                primeRead.Close();
                dataReader.Close();

                for (int i = 0; i < Convert.ToInt32(AnimeCountBox.Text) + 1; i++)
                {
                    try
                    {
                        if (Convert.ToBoolean(databaseDisplay[0, i].Value) == true)
                        {
                            turnRowOnOrOff(i);
                        }
                        else
                        {
                            databaseDisplay[8, i].ReadOnly = true;
                        }
                    }
                    catch
                    {
                        databaseDisplay[0, i].Value = false;
                        databaseDisplay[6, i].Value = false;
                        databaseDisplay[7, i].Value = false;
                    }
                }

                sortUnderlyingDataStructure();

            }
            catch
            {
                if (fileName.Length > 4)
                {
                    MessageBox.Show("That file does not exist.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    databaseDisplay.Rows.Remove(databaseDisplay.Rows[0]);
                }
                else
                {
                    databaseDisplay.Rows.Remove(databaseDisplay.Rows[0]);
                    //The user clicked the Cancel button, do nothing.
                }
            }
        }

        private void saveDatabaseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string fileName = openedFileName;

            StreamWriter dataWriter = new StreamWriter(fileName);

            for (int i = 0; i < databaseDisplay.RowCount - 1; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    if (j != 1)
                    {
                        dataWriter.WriteLine(databaseDisplay[j, i].Value);
                    }
                }
            }

            dataWriter.Close();
            
        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string fileName = Microsoft.VisualBasic.Interaction.InputBox("Enter a name for this file.\nIf the file already exists it will be overwritten.\n\nIf you do not specify a name and click OK, nothing will be saved.", "Save", "", SystemInformation.VirtualScreen.Width / 3, SystemInformation.VirtualScreen.Height / 3) + ".txt";

            if (fileName.Length > 4)
            {
                StreamWriter dataWriter = new StreamWriter(fileName);

                for (int i = 0; i < databaseDisplay.RowCount - 1; i++)
                {
                    for (int j = 0; j < 9; j++)
                    {
                        if (j != 1)
                        {
                            dataWriter.WriteLine(databaseDisplay[j, i].Value);
                        }
                    }
                }

                dataWriter.Close();
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ChangeLockStatusButton_MouseHover(object sender, EventArgs e)
        {
            toolTipsForButtons.Show("Clicking this button will lock/unlock the corresponding\nrow of the selected cell for editing.", ChangeLockStatusButton);
        }

        private void AddKnownEpisodeButton_MouseHover(object sender, EventArgs e)
        {
            toolTipsForButtons.Show("Clicking this button will add 1 to the third column of\nthe corresponding row of the selected cell.", AddKnownEpisodeButton);
        }

        private void AddObtainedEpisodeButton_MouseHover(object sender, EventArgs e)
        {
            toolTipsForButtons.Show("Clicking this button will add 1 to the fourth column of\nthe corresponding row of the selected cell.", AddObtainedEpisodeButton);
        }

        private void AddWatchedEpisodeButton_MouseHover(object sender, EventArgs e)
        {
            toolTipsForButtons.Show("Clicking this button will add 1 to the fifth column of\nthe corresponding row of the selected cell.", AddWatchedEpisodeButton);
        }

        private void Add1toAll3Button_MouseHover(object sender, EventArgs e)
        {
            toolTipsForButtons.Show("Clicking this button will add 1 to the third, fourth, and\nfifth columns of the corresponding row of the selected cell.", Add1toAll3Button);
        }

        private void AddXtoAll3Button_MouseHover(object sender, EventArgs e)
        {
            toolTipsForButtons.Show("Clicking this button will add a user defined value \"x\" to\nthe third, fourth, and fifth columns of the corresponding\nrow of the selected cell.", AddXtoAll3Button); 
        }

        private void ChangeKnownButton_MouseHover(object sender, EventArgs e)
        {
            toolTipsForButtons.Show("Clicking this button will enable the user to change the value\nof the third column of the corresponding row of the\nselected cell.", ChangeKnownButton);
        }

        private void ChangeObtainedButton_MouseHover(object sender, EventArgs e)
        {
            toolTipsForButtons.Show("Clicking this button will enable the user to change the value\nof the fourth column of the corresponding row of the\nselected cell.", ChangeObtainedButton);
        }

        private void ChangeWatchedButton_MouseHover(object sender, EventArgs e)
        {
            toolTipsForButtons.Show("Clicking this button will enable the user to change the value\nof the fifth column of the corresponding row of the\nselected cell.", ChangeWatchedButton);
        }

        private void ChangeCompletionStatusButton_MouseHover(object sender, EventArgs e)
        {
            toolTipsForButtons.Show("Clicking this button will check/uncheck the completion status\nfor the series of the corresponding row of the\nselected cell.", ChangeCompletionStatusButton);
        }

        private void ChangeUpToDateStatusButton_MouseHover(object sender, EventArgs e)
        {
            toolTipsForButtons.Show("Clicking this button will check/uncheck the up-to-date status\nfor the series of the corresponding row of the\nselected cell.", ChangeUpToDateStatusButton);
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("To add or edit a name in the database, simply double click on any cell in the last column on the right where the corresponding first cell in the same row is not checked (row is unlocked for editing).\n\n"
                                + "To change the data type for a series, simply click the dropdown list for the series (you may have to click twice on the dropdown list you wish to access).\n\nFor all other functionality "
                                + "explanations, simply hover your cursor over any of the buttons to the left of the database view, or the column headers within the database view.\n\nPlease keep in mind that any editing can only be "
                                + "done to rows with an unchecked Lock box.", "How to use...", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void versionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Made by James White\nVersion 1.02\n.NET Framework version 4.5\n64bit", "About", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
